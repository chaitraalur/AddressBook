#include "contact.h"
#include<string.h>
extern Contact dummyContacts[];

//initialize the address book with dummy data
void initialize(AddressBook *addressBook){
    addressBook->contactCount = 10;
    for(int i=0; i<addressBook->contactCount;i++)
    {
        addressBook->contacts[i]=dummyContacts[i];

    }
}
//List of all contacts in the address book
void listContacts(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0) {
        printf("No contacts in the address book.\n");
        return;
    }

printf("\n--- List of Contacts ---\n");
for(int i=0; i<addressBook->contactCount;i++)
{
    printf("%d. Name: %s, Phone: %s, Email: %s\n",i+1,
    addressBook->contacts[i].name,
    addressBook->contacts[i].phone,
    addressBook->contacts[i].email);
}
printf("-------------------------\n");
}

//Add a new contact
void createContact(AddressBook *addressBook)
{
    if(addressBook->contactCount>=MAX_CONTACTS)
    {
        printf("Address book is full. Cannot add more contacts.\n");
        return;
    }
    Contact newContact;
    printf("Enter Name: ");
    getchar();
    fgets(newContact.name,sizeof(newContact.name), stdin);
    newContact.name[strcspn(newContact.name, "\n")]='\0';
    printf("Enter Phone: ");
    fgets(newContact.phone,sizeof(newContact.phone), stdin);
    newContact.phone[strcspn(newContact.phone, "\n")]='\0';
    printf("Enter Email: ");
    fgets(newContact.email,sizeof(newContact.email), stdin);
    newContact.email[strcspn(newContact.email, "\n")]='\0';


    addressBook->contacts[addressBook->contactCount] = newContact;
    addressBook->contactCount++;
    printf("Contact added successfully.\n");
}

//search for contact by name
void searchContact(AddressBook *addressBook)
{
    char searchName[50];
    printf("Enter name to search: ");
    getchar();
    fgets(searchName,sizeof(searchName),stdin);
    searchName[strcspn(searchName, "\n")]='\0';
    //scanf("%s", searchName);
    for(int i=0; i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].name,searchName)==0)
        {
            printf("Contact Found: Name : %s, phone: %s, Email: %s\n",
            addressBook->contacts[i].name,
            addressBook->contacts[i].phone,
            addressBook->contacts[i].email);
            return;
        }
    }
    printf("Contact not found.\n");
}

//Edit a contact details
void editContact(AddressBook *addressBook){
    char searchName[50];
    printf("Enter name of contact to edit: ");
    getchar();
    fgets(searchName,sizeof(searchName),stdin);
    searchName[strcspn(searchName,"\n")]='\0';
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].name,searchName) == 0)
        {
            printf("Editing Contact: %s\n", addressBook->contacts[i].name);
            printf("Enter New Phone: ");
            fgets(addressBook->contacts[i].phone, sizeof(addressBook->contacts[i].phone),stdin);
            addressBook->contacts[i].phone[strcspn(addressBook->contacts[i].phone,"\n")]='\0';
            printf("Enter New Email: ");
            fgets(addressBook->contacts[i].email, sizeof(addressBook->contacts[i].email),stdin);
            addressBook->contacts[i].email[strcspn(addressBook->contacts[i].email,"\n")]='\0';
            printf("Contact updated successfully.\n");
            return;
        }
    }
    printf("Contact not found. \n");
}
void clearInputBuffer()
{
    while(getchar() !='\n');
}

//Delete contact
void deleteContact(AddressBook *addressBook)
{
    char searchName[50];
    printf("Enter name of contact to delete: ");
    //getchar();
    clearInputBuffer();
    fgets(searchName,sizeof(searchName),stdin);
    searchName[strcspn(searchName, "\n")] ='\0';
   // printf("Search Name: '%s'\n", searchName); 
    for(int i=0;i<addressBook->contactCount; i++)
    {
        if(strcmp(addressBook->contacts[i].name, searchName)==0)
        {
            for(int j=i;j<addressBook->contactCount -1;j++)
            {
                addressBook->contacts[j]=addressBook->contacts[j+1];
            }
            addressBook->contactCount--;
            printf("Contact deleted sucessfully.\n");
            return;
        }
    }
    printf("Contact not found.\n");
}
